Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_custom_request("Telemetry.Request", 
		"URL=https://nw-umwatson.events.data.microsoft.com/Telemetry.Request", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t81.inf", 
		"Mode=HTML", 
		"EncType=application/xml", 
		"BodyBinary=\\\\\\x0E\\x00\\x00<?xml version=\"1.0\"?>\n<req ver=\"2\">\n <tlm>\n  <src>\n   <desc>\n    <mach>\n     <os>\n      <arg nm=\"vermaj\" val=\"10\"/>\n      <arg nm=\"vermin\" val=\"0\"/>\n      <arg nm=\"verbld\" val=\"22631\"/>\n      <arg nm=\"vercsdbld\" val=\"3296\"/>\n      <arg nm=\"verqfe\" val=\"3296\"/>\n      <arg nm=\"csdbld\" val=\"3296\"/>\n      <arg nm=\"versp\" val=\"0\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"lcid\" val=\"1033\"/>\n      <arg nm=\"geoid"
		"\" val=\"166\"/>\n      <arg nm=\"sku\" val=\"101\"/>\n      <arg nm=\"domain\" val=\"0\"/>\n      <arg nm=\"portos\" val=\"0\"/>\n      <arg nm=\"ram\" val=\"16110\"/>\n      <arg nm=\"svolsz\" val=\"455\"/>\n      <arg nm=\"wimbt\" val=\"0\"/>\n      <arg nm=\"blddt\" val=\"220506\"/>\n      <arg nm=\"bldtm\" val=\"1250\"/>\n      <arg nm=\"bldbrch\" val=\"ni_release\"/>\n      <arg nm=\"os\" val=\"Windows\"/>\n      <arg nm=\"osver\" val=\"10.0.22621.3296.amd64fre.ni_release.220506-1250\"/>\n  "
		"    <arg nm=\"buildflightid\" val=\"068CE486-DC69-4164-81F7-99594A3E688B.1\"/>\n      <arg nm=\"expid\" val=\"\"/>\n      <arg nm=\"edition\" val=\"Core\"/>\n     </os>\n     <hw>\n      <arg nm=\"form\" val=\"2\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"deviceclass\" val=\"Windows.Desktop\"/>\n      <arg nm=\"sysmfg\" val=\"Dell Inc.\"/>\n      <arg nm=\"syspro\" val=\"Dell G15 5511\"/>\n      <arg nm=\"bv\" val=\"1.27.0\"/>\n      <arg nm=\"ram\" val=\"16384\"/>\n      <arg nm=\""
		"proccnt\" val=\"16\"/>\n      <arg nm=\"proclsp\" val=\"2304\"/>\n      <arg nm=\"wscpusc\" val=\"0\"/>\n      <arg nm=\"wsdsksc\" val=\"0\"/>\n      <arg nm=\"wscpudn\" val=\"11th Gen Intel(R) Core(TM) i7-11800H @ 2.30GHz\"/>\n      <arg nm=\"wsdgsc\" val=\"0\"/>\n      <arg nm=\"aoac\" val=\"1\"/>\n      <arg nm=\"bssku\" val=\"0A71\"/>\n      <arg nm=\"chid\" val=\"{28e7f8f5-ac96-5c2f-95dc-b5b356623892}\"/>\n      <arg nm=\"sdksz\" val=\"476\"/>\n     </hw>\n     <ctrl>\n      <arg nm=\"tm\" "
		"val=\"133573648895965430\"/>\n      <arg nm=\"mid\" val=\"8FFDD6B0-544B-436E-A577-7206C5FF724E\"/>\n      <arg nm=\"sample\" val=\"5173235\"/>\n      <arg nm=\"msft\" val=\"0\"/>\n      <arg nm=\"test\" val=\"0\"/>\n      <arg nm=\"scf\" val=\"0\"/>\n      <arg nm=\"commercialid\" val=\"\"/>\n      <arg nm=\"telemetry\" val=\"Required\"/>\n     </ctrl>\n    </mach>\n   </desc>\n  </src>\n  <reqs>\n   <req key=\"1\">\n    <namespace svc=\"watson\" ptr=\"generic\" gp=\"generic\" app=\"msedge.exe\">"
		"\n     <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"123.0.2420.81\"/>\n     <arg nm=\"p3\" val=\"msedge_elf.dll\"/>\n     <arg nm=\"p4\" val=\"123.0.2420.81\"/>\n     <arg nm=\"p5\" val=\"3039847\"/>\n     <arg nm=\"p6\" val=\"utility\"/>\n     <arg nm=\"p7\" val=\"0x517a7ed\"/>\n     <arg nm=\"p8\" val=\"0\"/>\n    </namespace>\n    <ctrl>\n     <arg nm=\"reportid\" val=\"0f11bfe9-99ae-4422-aa47-dad84a0ea1d0\"/>\n     <arg nm=\"procmeta.Channel\" val=\"\"/>\n     <arg nm=\""
		"procmeta.MetricsClientId\" val=\"bd83f107-a2d1-472f-a4b5-f0280acf67ee\"/>\n     <arg nm=\"procmeta.MetricsClientIdHash\" val=\"8592468008837887488\"/>\n     <arg nm=\"procmeta.MetricsSessionId\" val=\"178\"/>\n     <arg nm=\"procmeta.OfficialBuild\" val=\"1\"/>\n     <arg nm=\"procmeta.RuntimeVariationsSeedETag\" val=\"&quot;dtsc0W4gu0k+aq04MH6tI6dzrJnzVrQIGD2dWXOsXhg=&quot;\"/>\n     <arg nm=\"procmeta.UXConfigCorrelationId\" val=\"gGc5eakfLMLNZ57PC5gZLvPnqqToqD+cb6MIisUxk/0=\"/>\n     <arg nm=\""
		"procmeta.VariationsSeedETag\" val=\"\"/>\n    </ctrl>\n    <cmd nm=\"event\">\n     <arg nm=\"eventtype\" val=\"crashpad_exp\"/>\n     <arg nm=\"cat\" val=\"generic\"/>\n     <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"123.0.2420.81\"/>\n     <arg nm=\"p3\" val=\"msedge_elf.dll\"/>\n     <arg nm=\"p4\" val=\"123.0.2420.81\"/>\n     <arg nm=\"p5\" val=\"3039847\"/>\n     <arg nm=\"p6\" val=\"utility\"/>\n     <arg nm=\"p7\" val=\"0x517a7ed\"/>\n     <arg nm=\"p8\" val=\"0\"/>\n  "
		"   <arg nm=\"appsessionguid\" val=\"00002158-0008-0058-b4ce-9fa1868cda01\"/>\n    </cmd>\n   </req>\n  </reqs>\n </tlm>\n</req>\n", 
		LAST);

	lr_think_time(45);

	web_url("123.0.2420.81", 
		"URL=https://config.edge.skype.com/config/v1/Edge/123.0.2420.81?clientId=8592468008837887488&agents=EdgeFirstRun%2CEdgeFirstRunConfig&osname=win&client=edge&channel=stable&scpfre=0&osarch=x86_64&osver=10.0.22631&wu=1&devicefamily=desktop&uma=0&sessionid=178&mngd=0&installdate=1653266720&edu=0&bphint=2&soobedate=1653266647&fg=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t82.inf", 
		"Mode=HTML", 
		LAST);

	web_url("blocklist", 
		"URL=https://edge.microsoft.com/abusiveadblocking/api/v1/blocklist", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t83.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=14:YcArHH8TB_XieLMrgV13yr_WwqGy-PNV6hrSGqbS3Ik&cup2hreq=27a50f833c682508436f74dc586331313a2dcee3bc60904c30912357c05c1a71", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t84.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromiumcrx\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ghbmnnjooekpmoecnnnilnnbdlolhkhi\",\"cohort\":\"rrf@0.55\",\"disabled\":[{\"reason\":0}],\"enabled\":false,\"installdate\":6121,\"installedby\":\"external\",\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.10dc1ed2d8d9d4db369ddf7fd6f53effc9bfd87f46afdfc6c86cb637d2067a38\"}]},\"ping\":{\"ping_freshness\":\"{5fe26d9a-74c3-4096-9154-d02247f976cb}\",\"rd\":6289},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.55\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.55,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false},\"updatecheck\":{},\"version\":\"1.73.6\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":1,\"physmemory\":16,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\""
		"10.0.22631.3296\"},\"prodversion\":\"123.0.2420.81\",\"protocol\":\"3.1\",\"requestid\":\"{20d72053-cb35-4312-be38-910159e87b3d}\",\"sessionid\":\"{569d838e-f547-442c-a089-bdbc413f86bf}\",\"updaterversion\":\"123.0.2420.81\"}}", 
		LAST);

	web_url("V1Profile", 
		"URL=https://substrate.office.com/profileb2/v2.0/me/V1Profile", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t85.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("rewardsUserInfo", 
		"URL=https://www.bing.com/api/shopping/v1/savings/rewards/rewardsUserInfo", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t86.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"anid\":\"24E20FC69B32E9DA913F39B2FFFFFFFF\"}", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_custom_request("GetUserKeyData.srf", 
		"URL=https://login.live.com/ppsecure/GetUserKeyData.srf", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t87.inf", 
		"Mode=HTML", 
		"EncType=application/octet-stream", 
		"Body=<?xml version=\"1.0\"?>\n<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:ps=\"http://schemas.microsoft.com/Passport/SoapServices/PPCRL\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\">\n <s:Header>\n  <wsse:Security>\n   <wsse:BinarySecurityToken ValueType=\"ps:loginprooftoken\" id=\"LoginProofToken\">M.C522_BAY.0.U.Cl8bCiZfndVy6i0XLh/"
		"d0YeaUvFrAXeRbm7bO2prOYqxBRVyOO2iEol3O7BwZQw1LXZoCxPutZWGoZufWQXPQsX3gNfEx7xqg7bQDpI4dkAN6vilKbDOReK9ExPR8Byk41ejTOo36mCYmJfuUjOgBzOx0xyLQdJPlXnoqaF1lIZgbBfDOOvhX8EGogRZ5KFiSXFMNp/NBTbZVHNYPnt2N6upsnzDCsAnYT5ivGhZcf7wRoaHuaBZZNtCEmIhE7WsyUCziqoKxOQJ1MbxHHDP6GZpbXMbFTqMvNvJQm37koDm4DFNGCpWQFlC1keBbSuPBawI+nI+gJAIJORy1sd6AD3p+597eJdTGU101hnau/rxm+Gx+YEOdcK0Ja6mREpDY4fUpOXVtAWnK7grWumx/BcqMAfuJ7XeMzHabJ24RBk50UZXYoFIHQOnUEgSkbhpxBox9FZuL4scddc9ZsqHZQpt72Lyu6/9CFGZBXCuc4A9YQ/"
		"MqFtoK7AVBcWLEv5vrgeXowQruGtnB+agC/WH3QA=</wsse:BinarySecurityToken>\n  </wsse:Security>\n </s:Header>\n <s:Body>\n  <ps:GetKeyDataRequest xmlns:ps=\"http://schemas.microsoft.com/Passport/SoapServices/PPCRL\" Id=\"RSTS\" version=\"1.0\">\n   <ps:KeyPurposes>\n    <ps:KeyPurpose>AnaheimCredentialKey</ps:KeyPurpose>\n   </ps:KeyPurposes>\n  </ps:GetKeyDataRequest>\n </s:Body>\n</s:Envelope>\n", 
		LAST);

	web_add_cookie("ANON=; DOMAIN=www.bing.com");

	web_add_cookie("MUID=1FAA9EA6A71B68AA3F798F0BA6A869ED; DOMAIN=www.bing.com");

	web_add_cookie("_RwBf=ilt=56&ihpd=0&ispd=1&rc=58&rb=58&gb=0&rg=0&pc=58&mtu=0&rbb=0.0&g=0&cid=&clo=0&v=1&l=2024-01-29T08:00:00.0000000Z&lft=0001-01-01T00:00:00.0000000&aof=0&o=0&p=BINGCOPILOTWAITLIST&c=MR000T&t=5506&s=2023-07-11T15:16:42.2441082+00:00&ts=2024-01-30T02:04:14.4682238+00:00&rwred=0&wls=2&lka=0&lkt=0&TH=&dci=0&r=1&wlb=0&mta=0&aad=0&e=nn4PsRAhWb7lBEcZg7_FfsEsppQNAmByuYWHUcbjsJEKGMViLo3-wH9igJUUcnn9Fzdgzstszzj9byH6eZq7vpPcu4TeKRKEXJAhQwhtqrk&A=24E20FC69B32E9DA913F39B2FFFFFFFF&ard="
		"0001-01-01T00:00:00.0000000&rwdbt=0001-01-01T16:00:00.0000000-08:00&wle=0&ccp=0; DOMAIN=www.bing.com");

	web_url("ExpandedDomainsFilterGlobal.json", 
		"URL=https://www.bing.com/bloomfilterfiles/ExpandedDomainsFilterGlobal.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t88.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("www.garbarino.com", 
		"URL=https://www.garbarino.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t89.inf", 
		"Mode=HTML", 
		LAST);

	web_url("123.0.2420.81_2", 
		"URL=https://config.edge.skype.com/config/v1/Edge/123.0.2420.81?clientId=8592468008837887488&agents=Edge%2CEdgeConfig%2CEdgeServices%2CEdgeFirstRun%2CEdgeFirstRunConfig&osname=win&client=edge&channel=stable&scpfre=0&osarch=x86_64&osver=10.0.22631&wu=1&devicefamily=desktop&uma=0&sessionid=178&mngd=0&installdate=1653266720&edu=0&bphint=2&soobedate=1653266647&fg=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t90.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_custom_request("update", 
		"URL=https://edge.microsoft.com/componentupdater/api/v1/update?cup2key=7:N2bO2wPvcnS3kssCi_as0ymIU3757HVx96kXzuCbNuA&cup2hreq=ae7427d4d805cef00f7f37598a5158d8fa9d7923489993105bcc2173c8145488", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t91.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedge\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ohckeflnhegojcjlcpbfpciadgikcohk\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.40\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.26123BEF7D73536450862D2C4D44963D720AA80B6FC2D8496F559CB9C1FDEB00\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.40\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.4,\"AppVersion\":\"123.0.2420.81\",\""
		"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"0.0.1.4\"},{\"appid\":\"kpfehajjjbbcifeehjgfgnabifknmdad\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.94\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.42AF0D1905C8F1D8F6167365271C4549A73603B838BA58B9A664C57C00DB1EE5\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.94\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.94,\""
		"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"101.0.4906.0\"},{\"appid\":\"oankkpibpaokgecfckkdkgaoafllipag\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.28\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.44C48B9ECD87ACDDD850F9AA5E1C9D48B7A398DEC13D376CD62D55DADBD464A5\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.28\",\""
		"AppMajorVersion\":\"123\",\"AppRollout\":0.28,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"6498.2023.8.1\"},{\"appid\":\"eeobbhfgfagbclfofmgbdfoicabjdbkn\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.56\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.8BFD50D350D47445B57BB1D61BBDE41CEDA7AC43DC81FCE95BF1AC646D97D2A0\"}]},\"ping\":{\"r\":-2},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.56\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.56,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.0.0.8\"},{\"appid\":\"ndikpojcjlepofdkaaldkinkjbeeebkl\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.03\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.7B7D2723762BB51B662A5A8B41C4181069DEBE6A885689017238BE129698E7FE\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.03\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.03,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"10.34.0.52\"},{\"appid\":\"ahmaebgpfccdhgidjaidaoojjcijckba\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.34\",\"enabled\":true,\"lang\":\"en-US\",\""
		"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.34\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.34,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"fppmbhmldokgmleojlplaaodlkibgikh\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.09\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.A81D1959892AE4180554347DF1B97834ABBA2E1A5E6B9AEBA000ECEA26EABECC\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.09\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.09,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.15.0.1\"},{\"appid\":\"ojblfafjmiikbkepnnolpgbbhejhlcim\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.99\",\"enabled\":true,\"lang\":\"en-US\",\""
		"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.99\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.99,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"mkcgfaeepibomfapiapjaceihcojnphg\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.21\",\"enabled\":true,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.21\",\""
		"AppMajorVersion\":\"123\",\"AppRollout\":0.21,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"fgbafbciocncjfbbonhocjaohoknlaco\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.62\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.E257400C1E8A114B7B2F40C35A309A616323EFBA99442BBB0E1554F231E38809\"}]},\"ping\":{\"r\":-2},\""
		"targetingattributes\":{\"AppCohort\":\"rrf@0.62\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.62,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"2024.1.2.1\"},{\"appid\":\"ebkkldgijmkljgglkajkjgedfnigiakk\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.39\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.1B2BA8FC90BA68CD057B9CAAFFC218EAD59A23E37F79192ED37D0C3A7A8BAB03\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.39\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.39,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.0.0.20\"},{\"appid\":\"mpicjakjneaggahlnmbojhjpnileolnb\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.56\",\"enabled\":true,\"lang\":\"en-US\",\""
		"packages\":{\"package\":[{\"fp\":\"1.D0760C8DC53D9AC78138D8BB36E76A885A94363E33058BC33FB4E03162A2492C\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.56\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.56,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"4.0.0.19\"},{\"appid\":\"alpjnmnfbgfkmmpcfpejmmoebdndedno\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.18\",\""
		"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.ACAF273151A17537328DD498705F2F589745E014A1BBA4FC2B3FA2729CF4A5F6\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.18\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.18,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"11.0.0.0\"},{\"appid\":\""
		"plbmmhnabegcabfbcejohgjpkamkddhn\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.29\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.A3E4A6C666CAF55888EF7980E6A580321024B592F024CB06B179B1793281EF3B\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.29\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.29,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\""
		"version\":\"3023\"},{\"appid\":\"omnckhpgfmaoelhddliebabpgblmmnjp\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.55\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.DD91C7C496E4D9E8DF5BEAA3D33D45F9EF196B4F888D0FAC50EAF08CAD6B29D7\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.55\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.55,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\""
		"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.0.0.2\"},{\"appid\":\"lkkdlcloifjinapabfonaibjijloebfb\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.43\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.3DF98661B2C8EBCA31A06084870DCEBEA5B939B1844C8856381048EF81B69AD3\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.43\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.43,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\""
		":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"4.0.3.0\"},{\"appid\":\"jbfaflocpnkhbgcijpkiafdpbjkedane\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.65\",\"enabled\":true,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.65\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.65,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\""
		":\"1.0.0.25\"},{\"appid\":\"jcmcegpcehdchljeldgmmfbgcpnmgedo\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.51\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.A4243306648063AB62C8FD0E9806530D38067CFAA823D2BE561D57C1D8525F2A\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.51\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.51,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\""
		"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.20240321.1.0\"},{\"appid\":\"llmidpclgepbgbgoecnhcmgfhmfplfao\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.41\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.E4707DB023A89182D0D73502F172A7661F10AD503B44322E85BF05AC38144605\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.41\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.41,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\""
		"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"2.0.6486.0\"},{\"appid\":\"hjaimielcgmceiphgjjfddlgjklfpdei\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.93\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.A00289AF85D31D698A0F6753B6CE67DBAB4BDFF639BDE5FC588A5D5D8A3885D5\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.93\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.93,\""
		"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"1.0.0.5\"},{\"appid\":\"lfmeghnikdkbonehgjihjebgioakijgn\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.56\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.E7727C48F2FC3649530D39F110AD37F750538845D0E271C1B26CFE6B3E6A26E3\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.56\",\"AppMajorVersion"
		"\":\"123\",\"AppRollout\":0.56,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"2.0.0.9\"},{\"appid\":\"bplppjpoiabhjhoepjajdfpcklleoeih\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.23\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.23\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.23,\"AppVersion\":\""
		"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"cllppcmmlnkggcmljjfigkcigaajjmid\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.21\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.EA68AB7B2E67BFCE9229D4AE314FAA6A910F326BEB2E9FEB7EECFE1C84C467A9\"}]},\"ping\":{\"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.21\",\""
		"AppMajorVersion\":\"123\",\"AppRollout\":0.21,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"122.17403.17389.1\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.61\",\"enabled\":true,\"installdate\":-1,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.F09EE458BC072D34B22EAE8853E44B3712E7CFD257A7CBED20BA3B1D9D652B3B\"}]},\"ping\":{\""
		"r\":-2},\"targetingattributes\":{\"AppCohort\":\"rrf@0.61\",\"AppMajorVersion\":\"123\",\"AppRollout\":0.61,\"AppVersion\":\"123.0.2420.81\",\"IsInternalUser\":false,\"Priority\":false,\"Updater\":\"Omaha\",\"UpdaterVersion\":\"1.3.185.29\"},\"updatecheck\":{},\"version\":\"2024.1.5.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":1,\"physmemory\":16,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"nacl_arch\":\"x86-64\",\"os\":{\""
		"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22631.3296\"},\"prodversion\":\"123.0.2420.81\",\"protocol\":\"3.1\",\"requestid\":\"{fc0ab600-edae-4bea-88be-ceeba7353b54}\",\"sessionid\":\"{0b3615c7-da9e-40af-a43b-eda41f08128b}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":1,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.185.29\"},\"updaterversion\":\"123.0.2420.81\"}}", 
		LAST);

	web_custom_request("rewardsUserInfo_2", 
		"URL=https://www.bing.com/api/shopping/v1/savings/rewards/rewardsUserInfo", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t92.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"anid\":\"24E20FC69B32E9DA913F39B2FFFFFFFF\"}", 
		LAST);

	web_url("notification.json", 
		"URL=https://notification.adblockplus.org/notification.json?addonName=adblockpluschrome&addonVersion=3.25&application=edg&applicationVersion=123.0.0.0&platform=chromium&platformVersion=123.0.0.0&lastVersion=202403041928-13%2F4-14%2F4-15%2F5-16%2F5-17%2F7-18%2F5-21%2F4-24%2F2-27%2F5&downloadCount=4%2B&disabled=false&manifestVersion=2&firstVersion=2022", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t93.inf", 
		"Mode=HTML", 
		LAST);

	web_url("123.0.2420.81_3", 
		"URL=https://config.edge.skype.com/config/v1/Edge/123.0.2420.81?clientId=8592468008837887488&agents=EdgeRuntime%2CEdgeRuntimeConfig%2CEdgeDomainActions&osname=win&client=edge&channel=stable&scpfre=0&osarch=x86_64&osver=10.0.22631&wu=1&devicefamily=desktop&uma=0&sessionid=178&mngd=0&installdate=1653266720&edu=0&bphint=2&soobedate=1653266647&fg=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t94.inf", 
		"Mode=HTML", 
		LAST);

	web_url("V1Profile_2", 
		"URL=https://substrate.office.com/profileb2/v2.0/me/V1Profile", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t95.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(5);

	web_custom_request("update_2", 
		"URL=https://edge.microsoft.com/componentupdater/api/v1/update", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t96.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedge\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"fgbafbciocncjfbbonhocjaohoknlaco\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.62\",\"enabled\":true,\"event\":[{\"download_time_ms\":8080,\"downloaded\":7759,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"2024.3.25.1\",\"previousversion\":\"2024.1.2.1\",\"total\":7759,\"url\":\"http://msedge.b.tlu.dl.delivery.mp.microsoft.com/filestreamingservice/files/"
		"6ff4d14b-e076-4567-9c51-344ecdc3181a?P1=1713335375&P2=404&P3=2&P4=Kka4yL0NL7U2gl5GxWBFlXm99AaOFXKJ5tB5CXc4WiKbqjzAHb%2bDugVVZ6%2blNhXWfg7h%2b7aYZWB1NQP9TN4U2A%3d%3d\"},{\"eventresult\":1,\"eventtype\":3,\"install_time_ms\":190,\"nextfp\":\"1.A3CA819F81D9DCA57840EF075B95084F67DB8F7B227D54D803C9EE7378D52870\",\"nextversion\":\"2024.3.25.1\",\"previousfp\":\"1.E257400C1E8A114B7B2F40C35A309A616323EFBA99442BBB0E1554F231E38809\",\"previousversion\":\"2024.1.2.1\"}],\"installdate\":-1,\"lang\":\"en-US\","
		"\"packages\":{\"package\":[{\"fp\":\"1.A3CA819F81D9DCA57840EF075B95084F67DB8F7B227D54D803C9EE7378D52870\"}]},\"version\":\"2024.3.25.1\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":1,\"physmemory\":16,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22631.3296\"},\"prodversion\":\"123.0.2420.81\",\"protocol\":\"3.1\",\"requestid\":\""
		"{40f878ba-02c0-40d9-8daf-081a7d03344a}\",\"sessionid\":\"{0b3615c7-da9e-40af-a43b-eda41f08128b}\",\"updaterversion\":\"123.0.2420.81\"}}", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_custom_request("update_3", 
		"URL=https://edge.microsoft.com/componentupdater/api/v1/update", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t97.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedge\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"plbmmhnabegcabfbcejohgjpkamkddhn\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.29\",\"enabled\":true,\"event\":[{\"download_time_ms\":4028,\"downloaded\":70253,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"3026.0.0.0\",\"previousversion\":\"3023\",\"total\":70253,\"url\":\"http://msedge.b.tlu.dl.delivery.mp.microsoft.com/filestreamingservice/files/"
		"8cebbefd-3ab9-46d7-b3e0-fd9645591424?P1=1713466633&P2=404&P3=2&P4=Vy0YwWo6Atyr1gfuCOjp%2ftmzYXHvc7vwVTIDnmjrh5OyP3wi3Xfqidcyv%2ft7YI9VAuSayG%2fNzlVOUbWTjmydAg%3d%3d\"},{\"eventresult\":1,\"eventtype\":3,\"install_time_ms\":197,\"nextfp\":\"1.F409260DE9C4B5D70B2C4F05AFAE2C37DB0C5B0F2A48F69575BAC81AE36416A3\",\"nextversion\":\"3026.0.0.0\",\"previousfp\":\"1.A3E4A6C666CAF55888EF7980E6A580321024B592F024CB06B179B1793281EF3B\",\"previousversion\":\"3023\"}],\"lang\":\"en-US\",\"packages\":{\"package\":"
		"[{\"fp\":\"1.F409260DE9C4B5D70B2C4F05AFAE2C37DB0C5B0F2A48F69575BAC81AE36416A3\"}]},\"version\":\"3026.0.0.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":1,\"physmemory\":16,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22631.3296\"},\"prodversion\":\"123.0.2420.81\",\"protocol\":\"3.1\",\"requestid\":\""
		"{95a05ebe-5329-4e5a-9703-c4de54e625a9}\",\"sessionid\":\"{0b3615c7-da9e-40af-a43b-eda41f08128b}\",\"updaterversion\":\"123.0.2420.81\"}}", 
		LAST);

	web_add_cookie("_ga=GA1.1.1358661906.1712891361; DOMAIN=www.garbarino.com");

	web_add_cookie("_ga_3SQN45GM23=GS1.1.1712891361.1.0.1712891361.0.0.0; DOMAIN=www.garbarino.com");

	web_add_cookie("_gcl_au=1.1.1888930314.1712891361.1400839397.1712891361.1712891361; DOMAIN=www.garbarino.com");

	web_submit_data("signin", 
		"Action=https://www.garbarino.com/api/user/signin", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t98.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=data_json", "Value={\"email\":\"nalado4430@kravify.com\",\"password\":\"nalado4430\"}", ENDITEM, 
		LAST);

	web_custom_request("get_info", 
		"URL=https://bot.webpushr.com/prompt/get_info", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t99.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"site_id\":\"BBlgrWPYiRhXLIFaE6w3-ZsHkB6_UWrsUOngFopOURf1z0DOwITornwz-DO_UpqaOB5_7nnMdmLK3DlIwxMzoBk\",\"browser\":\"Chrome\"}", 
		LAST);

	web_add_cookie("_gcl_au=1.1.1888930314.1712891361.1400839397.1712891361.1712891374; DOMAIN=www.garbarino.com");

	web_add_cookie("_ga_3SQN45GM23=GS1.1.1712891361.1.1.1712891374.0.0.0; DOMAIN=www.garbarino.com");

	web_url("products-ids", 
		"URL=https://www.garbarino.com/api/catalog/wishlist/products-ids", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t100.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("session", 
		"URL=https://analytics.webpushr.com/impression/session", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t101.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"status\":\"session_new_to_push\",\"site_id\":\"BBlgrWPYiRhXLIFaE6w3-ZsHkB6_UWrsUOngFopOURf1z0DOwITornwz-DO_UpqaOB5_7nnMdmLK3DlIwxMzoBk\"}", 
		LAST);

	web_custom_request("prompt", 
		"URL=https://analytics.webpushr.com/impression/prompt", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t102.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"status\":\"custom_prompt\",\"site_id\":\"BBlgrWPYiRhXLIFaE6w3-ZsHkB6_UWrsUOngFopOURf1z0DOwITornwz-DO_UpqaOB5_7nnMdmLK3DlIwxMzoBk\"}", 
		LAST);

	web_submit_data("shop", 
		"Action=https://www.garbarino.com/api/catalog/shop", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t103.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=data_json", "Value={\"filters\":[\"celulares-notebooks-y-tecnologia\",\"celulares-y-telefonos\",\"celulares-libres\"],\"page\":1}", ENDITEM, 
		LAST);

	web_custom_request("update_4", 
		"URL=https://edge.microsoft.com/componentupdater/api/v1/update", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t104.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedge\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"jcmcegpcehdchljeldgmmfbgcpnmgedo\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.51\",\"enabled\":true,\"event\":[{\"download_time_ms\":4037,\"downloaded\":40420,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"309.55323.1.0\",\"previousversion\":\"1.20240321.1.0\",\"total\":40420,\"url\":\"http://msedge.b.tlu.dl.delivery.mp.microsoft.com/filestreamingservice/files/"
		"009c526a-542f-4d30-8219-9d5157b9c7e2?P1=1713426501&P2=404&P3=2&P4=ON0nxo%2bO%2br7SLl95rmoELV6gmBCxxRfvKkm%2bogGv4u3KRY2QDrkkNnDucCI7fpuiiod9AfC0JtwQcwa4f6muGg%3d%3d\"},{\"eventresult\":1,\"eventtype\":3,\"install_time_ms\":223,\"nextfp\":\"1.48D8A414A537761A409B004A7950178AF4FAD1D9E548600FB5E333C837CD951D\",\"nextversion\":\"309.55323.1.0\",\"previousfp\":\"1.A4243306648063AB62C8FD0E9806530D38067CFAA823D2BE561D57C1D8525F2A\",\"previousversion\":\"1.20240321.1.0\"}],\"installdate\":-1,\"lang\":\""
		"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.48D8A414A537761A409B004A7950178AF4FAD1D9E548600FB5E333C837CD951D\"}]},\"version\":\"309.55323.1.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":1,\"physmemory\":16,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22631.3296\"},\"prodversion\":\"123.0.2420.81\",\"protocol\":\"3.1\",\""
		"requestid\":\"{580f896d-1272-423e-90f6-398476e3af54}\",\"sessionid\":\"{0b3615c7-da9e-40af-a43b-eda41f08128b}\",\"updaterversion\":\"123.0.2420.81\"}}", 
		LAST);

	lr_think_time(5);

	web_custom_request("update_5", 
		"URL=https://edge.microsoft.com/componentupdater/api/v1/update", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t105.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"msedge\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"llmidpclgepbgbgoecnhcmgfhmfplfao\",\"brand\":\"EPBR\",\"cohort\":\"rrf@0.41\",\"enabled\":true,\"event\":[{\"download_time_ms\":4025,\"downloaded\":2195228,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"2.0.6576.0\",\"previousversion\":\"2.0.6486.0\",\"total\":2195228,\"url\":\"http://msedge.b.tlu.dl.delivery.mp.microsoft.com/filestreamingservice/files/"
		"a788a458-436a-4e29-9ec3-72aada462a68?P1=1713379973&P2=404&P3=2&P4=SGJTe4RMijUftf0aiWl0xwkY8T4%2b8g9CdgJv6B77UdTeKtUEz13T%2fjaYiQsL0bqUTib1STPPfzXqDVlbLvcdUw%3d%3d\"},{\"eventresult\":1,\"eventtype\":3,\"install_time_ms\":280,\"nextfp\":\"1.499678427A59B9EE33B37D1746A495BDB2A2132554FC7EBEE2AA947EB76993F7\",\"nextversion\":\"2.0.6576.0\",\"previousfp\":\"1.E4707DB023A89182D0D73502F172A7661F10AD503B44322E85BF05AC38144605\",\"previousversion\":\"2.0.6486.0\"}],\"lang\":\"en-US\",\"packages\":{\""
		"package\":[{\"fp\":\"1.499678427A59B9EE33B37D1746A495BDB2A2132554FC7EBEE2AA947EB76993F7\"}]},\"version\":\"2.0.6576.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":1,\"physmemory\":16,\"sse\":1,\"sse2\":1,\"sse3\":1,\"sse41\":1,\"sse42\":1,\"ssse3\":1},\"ismachine\":1,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22631.3296\"},\"prodversion\":\"123.0.2420.81\",\"protocol\":\"3.1\",\"requestid\":\""
		"{8ca4f1de-1aba-458f-9987-43888a8b3b4a}\",\"sessionid\":\"{0b3615c7-da9e-40af-a43b-eda41f08128b}\",\"updaterversion\":\"123.0.2420.81\"}}", 
		LAST);

	web_add_cookie("_ga_3SQN45GM23=GS1.1.1712891361.1.1.1712891379.0.0.0; DOMAIN=www.garbarino.com");

	web_url("8d410290-2116-4244-b917-2523ca7b0585", 
		"URL=https://www.garbarino.com/api/catalog/product/8d410290-2116-4244-b917-2523ca7b0585", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.garbarino.com/celulares-notebooks-y-tecnologia/celulares-y-telefonos/celulares-libres", 
		"Snapshot=t106.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}