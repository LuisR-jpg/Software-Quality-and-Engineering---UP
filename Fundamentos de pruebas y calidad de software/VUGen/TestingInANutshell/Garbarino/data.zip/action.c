Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("www.garbarino.com", 
		"URL=https://www.garbarino.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/static-v-shop/1712256370368/fonts/Roboto-Regular.6887b6f2.woff2", "Referer=https://d2eebw31vcx88p.cloudfront.net/garbarino/static-v-shop/1712256370368/css/v-shop.9bd2deec.css", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/static-v-shop/1712256370368/fonts/materialdesignicons-webfont.62ff6e3a.woff2", "Referer=https://d2eebw31vcx88p.cloudfront.net/garbarino/static-v-shop/1712256370368/css/v-shop.9bd2deec.css", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/static-v-shop/1712256370368/fonts/NunitoSans-Regular.e9346522.woff2", "Referer=https://d2eebw31vcx88p.cloudfront.net/garbarino/static-v-shop/1712256370368/css/v-shop.9bd2deec.css", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/static-v-shop/1712256370368/fonts/OpenSans-Regular.bfdb5bc0.woff2", "Referer=https://d2eebw31vcx88p.cloudfront.net/garbarino/static-v-shop/1712256370368/css/v-shop.9bd2deec.css", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIzLjAuNjMxMi4xMDcSGQnjFemd-Nrk9hIFDULauvchHR2Oky1DQF0SIAkHTLnezRl6kxIFDXhvEhkSBQ3OQUx6ISJyyOgA90SpEhkJTipy9SV1F30SBQ2apPEJIc4BXnHb30D5?alt=proto", "Referer=", ENDITEM, 
		"Url=https://cdn.webpushr.com/app.min.js", ENDITEM, 
		"Url=/webpushr-sw.js", ENDITEM, 
		"Url=https://cdn.webpushr.com/sw-server.min.js", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/e0bc99d42f591f70c5a93da61fd5d46e546f4d23.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/a49213b739e5ef9369c8a804e3920afc54448fa8.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/eb439b150b42351ecceaa1b45e430f8fec6be794.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/c6ec786930f22b4e33d84616bb015b6b071f4f9e.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/f91ef15dcd387bc806c6ee8f5f3db5fdfa0da12e.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/21f19c8a60c84684b348c65f0ee137d4a6f424dc.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/caa6c3fb53bc2f18d6c489d6af9ceec17425fa5d.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/d794cbbfd49819ec77bfd56a3375e4d8a33ee145.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/283a39c25c7c4cde94383ce1cbf0fc50376d1f6f.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/2235838f637455f618f6847ccc26b6a844bfa67f.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/33c5d7c6bebcdd072b9fcbd0c0c8996da9994c50.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/8f1f8ef88e94c047643a9254dda8528ddeea0c56.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/e45e29050c435ab0b6ac146ac8f5543f98364273.jpg.webp", ENDITEM, 
		"Url=https://cdn.webpushr.com/siteassets/v9gXmgAzrZ.jpeg", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/8c5570a8f12a823659f352baf4b94354c762f1ee.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/1442e28699b062932784e36dce1c796a2e2ece11.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/866ff49ae1ea889d29b7e41574da148ef2f5220b.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/3cb991672d400ccc687457a6cb4a595de4739e29.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/06c064b9aba51c3b690be7f426415367b00092c8.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/b6f024f009a2f9ce62c8cd2afc0c17f38461c7db.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/0a33852a228358a8286921bc659838ec658385b0.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/35c1ff440b470e625c910b0f7d2f88f5fec0e744.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/c5c4d569c59d98e04382a87cf8390a2be1a57504.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/dfde1e8a197df62f9ed6aa791756b85fe9fb603c.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/874d98dd16d115f9cde757a65e935dac80238e69.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/4fb9ce42571f177dae899fca0f6e221307100bc0.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/7b56eac94fb38453ffb54453e91b78a3c6296676.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/0039f21c21b8e66edf94e60ba5b1032db4563196.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/0aea5e93d943ce3224bed36bf1df4a7d5075fbcc.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/26c2e1e67403fa1b443c63bffba4057d34de9a6f.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/73fe98cd3dd621d4e97ad1445059d1c238675cb0.jpg.webp", ENDITEM, 
		"Url=https://d2eebw31vcx88p.cloudfront.net/garbarino/uploads/ac2ec8694c6c0ffed9ce6f9405de4d0bfede70a0.jpg.webp", ENDITEM, 
		LAST);

	/* Case_g01_01_look_cellphone  */

	web_custom_request("get_info", 
		"URL=https://bot.webpushr.com/prompt/get_info", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"site_id\":\"BBlgrWPYiRhXLIFaE6w3-ZsHkB6_UWrsUOngFopOURf1z0DOwITornwz-DO_UpqaOB5_7nnMdmLK3DlIwxMzoBk\",\"browser\":\"Chrome\"}", 
		LAST);

	web_custom_request("session", 
		"URL=https://analytics.webpushr.com/impression/session", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"status\":\"session_new_to_push\",\"site_id\":\"BBlgrWPYiRhXLIFaE6w3-ZsHkB6_UWrsUOngFopOURf1z0DOwITornwz-DO_UpqaOB5_7nnMdmLK3DlIwxMzoBk\"}", 
		LAST);

	web_custom_request("prompt", 
		"URL=https://analytics.webpushr.com/impression/prompt", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"status\":\"custom_prompt\",\"site_id\":\"BBlgrWPYiRhXLIFaE6w3-ZsHkB6_UWrsUOngFopOURf1z0DOwITornwz-DO_UpqaOB5_7nnMdmLK3DlIwxMzoBk\"}", 
		LAST);

	lr_think_time(4);

	lr_start_transaction("Case_g01_01_look_cellphone");

	web_submit_data("shop", 
		"Action=https://www.garbarino.com/api/catalog/shop", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=application/json", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=data_json", "Value={\"filters\":[\"celulares-notebooks-y-tecnologia\",\"celulares-y-telefonos\",\"celulares-libres\"],\"page\":1}", ENDITEM, 
		LAST);

	lr_end_transaction("Case_g01_01_look_cellphone",LR_AUTO);

	/* Cerrar alert */

	lr_think_time(21);

	web_custom_request("prompt_2", 
		"URL=https://analytics.webpushr.com/impression/prompt", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://www.garbarino.com/", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"status\":\"Dismiss\",\"site_id\":\"BBlgrWPYiRhXLIFaE6w3-ZsHkB6_UWrsUOngFopOURf1z0DOwITornwz-DO_UpqaOB5_7nnMdmLK3DlIwxMzoBk\"}", 
		LAST);

	lr_think_time(10);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=14:Q8ehF29mFVmB5KLSyAxK7gxEqUI-O9qanNv6wnQAmQM&cup2hreq=775f0a2c551239a6a277bab7f12f0f26812e0ca3f80ce62433ba122a5730de2e", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"accept_locale\":\"ES419500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f:2anf@0.025\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"ping\":{\"ping_freshness\":\"{fe93d95d-6093-4bfa-b366-7063653fe02a}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":"
		"\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.aeedb246d19256a956fedaa89fb62423ae5bd8855a2a1f3189161cf045645a19\"}]},\"ping\":{\"ping_freshness\":\"{cabe7607-65ad-48be-957a-e3b1f96dc52e}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"1.3.36.141\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1zdx:\",\"cohortname\":\"4.10.2710.0 to Windows (x86/x64)\",\"enabled\":true,\"installdate\""
		":5936,\"lang\":\"es-419\",\"ping\":{\"ping_freshness\":\"{39a47d13-a95e-4488-bcea-62bee667e276}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.c900ba9a2d8318263fd43782ee6fd5fb50bad78bf0eb2c972b5922c458af45ed\"}]},\"ping\":{\"ping_freshness\":\""
		"{07867792-5add-4eed-8c73-0399e1b4cee0}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{d61824de-73b8-4397-b5a7-45c443e3c025}\",\"rd\":6310},\"updatecheck\":{},\"version\":\""
		"9.49.1\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GGLS\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6153,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.90b91aaa463ef666bf030c7f14b7046738dee86d64321b28cb834d04bbfea4b3\"}]},\"ping\":{\"ping_freshness\":\"{3030dbd5-1ef6-41f9-8e9a-80694d5732f5}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"2024.3.25.1\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"GGLS\",\"cohort\":"
		"\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.0312d42f5f3877a12e6f5da85001549cd9dd435debf72aee5652d1f6a550d351\"}]},\"ping\":{\"ping_freshness\":\"{509e2adf-ff7a-4a2f-b373-1f870439e39b}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"442\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\""
		"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{90899d95-e986-49cf-8157-a0febf83d32b}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:2879:\",\"cohortname\":\"Auto androidlowmem\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\""
		"1.f9e33fa1309505c2b29bbd72b5d5cf48375d1f329ea5efbf1abed40bd4f62fb5\"}]},\"ping\":{\"ping_freshness\":\"{e502b5bc-511c-47ce-b35c-57f3d930560d}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"8662\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"ping\":{\"ping_freshness\":\"{55259bd3-0fba-469c-9b91-f677701daa24}\",\"rd\":6310},\"updatecheck\":{},\"version\":\""
		"1.0.7.1652906823\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.0bd20c0ed22291b160114420a22e8ae9fd79a002cff2efdff99285f35a15f629\"}]},\"ping\":{\"ping_freshness\":\"{89912e0e-6eb5-4b39-a8d5-eb3b5091e582}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"3026\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort"
		"\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\"ping_freshness\":\"{7523a895-7b88-4548-996b-38e9d1ed71fd}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f:23ml@0.1\",\"cohortname\":\"M108 and Above\",\"enabled\":true,\""
		"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.c45cd56a0a8da0883c8f9757b31891d6c628f38cb80724015ffdf33b419a73f3\"}]},\"ping\":{\"ping_freshness\":\"{35788f1f-64b5-4438-bae0-9b59aba1fe9b}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"2023.11.27.1202\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\""
		"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{443f7190-41ea-4041-92f8-5b8eff44782d}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.f4f1eb04881095d1cc8f2e1799a8144c10476dc1088a03ecdb4418644040a554\"}]},\"ping\":{\""
		"ping_freshness\":\"{149c08c8-3d4c-42c2-ade7-12211406896f}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"63\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"GGLS\",\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6153,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.317672878e66fe3117c5c27c1c7b2bacc00f60863e1a6bebf0a7ffe43353b08b\"}]},\"ping\":{\"ping_freshness\":\"{32c09f75-f6bc-4352-8c97-dfb1d953aa4c}\",\"rd\":6310},\""
		"updatecheck\":{},\"version\":\"2024.4.10.0\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\"{f316ec03-c7cc-4cc7-b86f-2621207b3e40}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"1.0.0.15\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\""
		"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.bd890442b581ed9e10f8f1357de6b3ba6225fd80ba5402ea4e54a1619302c0ed\"}]},\"ping\":{\"ping_freshness\":\"{ab3f6965-f836-45b4-bfe8-b6519929b0a9}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"921\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":5936,\""
		"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{22e27b1f-4d72-478c-88a1-6500c6682037}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"GGLS\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6174,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\""
		"1.2224fd8b6488a5197111194ab074a6d83292959c5ea7f034f46cc51e8a280a50\"}]},\"ping\":{\"ping_freshness\":\"{ee7fbe68-53c7-4244-9c92-51d7ef84ab52}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"2024.4.10.1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"GGLS\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\""
		"ping_freshness\":\"{0a39f14a-6b3b-4b88-85bc-2ad91ba2db32}\",\"rd\":6310},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5936,\"lang\":\"es-419\",\"packages\":{\"package\":[{\"fp\":\"1.120a8783d5ccfe1107dea29a51959fbbebbe1d57ad974dc9ee5b65323c90dab4\"}]},\"ping\":{\"ping_freshness\":\"{ecb50998-c932-4396-a6c0-65b76e942de7}\",\"rd\":6310},\""
		"updatecheck\":{},\"version\":\"2024.3.27.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22631.3296\"},\"prodversion\":\"123.0.6312.107\",\"protocol\":\"3.1\",\"requestid\":\"{421513dc-8f71-47df-88f5-93234c59c3c9}\",\"sessionid\":\""
		"{2d05fdde-c64f-4b11-bf8b-2c874e4a3880}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.372\"},\"updaterversion\":\"123.0.6312.107\"}}", 
		LAST);

	lr_start_transaction("Case_g01_02_select_cellphone");

	web_custom_request("upload", 
		"URL=https://beacons.gcp.gvt2.com/domainreliability/upload", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"entries\":[{\"failure_data\":{\"custom_error\":\"net::ERR_CERT_COMMON_NAME_INVALID\"},\"network_changed\":false,\"protocol\":\"\",\"request_age_ms\":72859,\"request_elapsed_ms\":5388,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"ssl.cert.name_invalid\",\"url\":\"https://www.googletagmanager.com/\",\"was_proxied\":false}],\"reporter\":\"chrome\"}", 
		LAST);

	web_url("20e16b85-a660-4d74-b87e-c9cecb9de043", 
		"URL=https://www.garbarino.com/api/catalog/product/20e16b85-a660-4d74-b87e-c9cecb9de043", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.garbarino.com/celulares-notebooks-y-tecnologia/celulares-y-telefonos/celulares-libres", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		LAST);

	/* Case_g01_02_select_cellphone  */

	lr_end_transaction("Case_g01_02_select_cellphone",LR_AUTO);

	/* Case_g01_03_buy_cellphone  */

	lr_think_time(33);

	lr_start_transaction("Case_g01_03_buy_cellphone");

	web_submit_data("item", 
		"Action=https://www.garbarino.com/api/cart/item", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"RecContentType=application/json", 
		"Referer=https://www.garbarino.com/p/samsung-galaxy-z-fold5-5g-dual-sim-256-gb-12-gb-ram-blue/20e16b85-a660-4d74-b87e-c9cecb9de043", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=data_json", "Value={\"qty\":1,\"refType\":\"product\",\"refId\":\"ca1f04f6-2e49-487f-8ba7-5a34c233e174\",\"customization\":{},\"sum\":true}", ENDITEM, 
		LAST);

	web_url("20e16b85-a660-4d74-b87e-c9cecb9de043_2", 
		"URL=https://www.garbarino.com/api/catalog/product-upsells/20e16b85-a660-4d74-b87e-c9cecb9de043", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://www.garbarino.com/p/samsung-galaxy-z-fold5-5g-dual-sim-256-gb-12-gb-ram-blue/20e16b85-a660-4d74-b87e-c9cecb9de043", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Case_g01_03_buy_cellphone",LR_AUTO);

	return 0;
}